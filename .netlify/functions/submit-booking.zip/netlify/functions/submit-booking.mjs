
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/submit-booking-2-0.js
import sgMail from "@sendgrid/mail";
sgMail.setApiKey(process.env.SENDGRID_API_KEY);
var ALLOWED_ORIGINS = /* @__PURE__ */ new Set([
  "https://seventattoolv.com",
  "https://www.seventattoolv.com",
  "https://seventattoolv.myshopify.com"
]);
var ENFORCE_ORIGIN = false;
function corsHeaders(origin, req) {
  const reqHeaders = req?.headers?.get("access-control-request-headers");
  return {
    "Access-Control-Allow-Origin": origin || "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": reqHeaders || "Content-Type, Accept",
    "Access-Control-Max-Age": "86400",
    Vary: "Origin, Access-Control-Request-Headers"
  };
}
var submit_booking_2_0_default = async (req, context) => {
  const method = (req.method || "GET").toUpperCase();
  const origin = req.headers.get("origin") || "";
  console.log("Incoming Origin:", origin);
  const isAllowed = ALLOWED_ORIGINS.has(origin) || !ENFORCE_ORIGIN;
  const allowOrigin = isAllowed ? origin || "*" : origin || "*";
  if (method === "OPTIONS") {
    return new Response("", {
      status: 204,
      headers: corsHeaders(allowOrigin, req)
    });
  }
  if (method !== "POST") {
    return new Response(
      JSON.stringify({ ok: false, error: "Method not allowed" }),
      {
        status: 405,
        headers: corsHeaders(allowOrigin, req)
      }
    );
  }
  if (!isAllowed) {
    return new Response(
      JSON.stringify({ ok: false, error: `Origin not allowed: ${origin}` }),
      {
        status: 403,
        headers: corsHeaders(allowOrigin, req)
      }
    );
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ ok: false, error: "Invalid JSON" }), {
      status: 400,
      headers: corsHeaders(allowOrigin, req)
    });
  }
  if (body.website && String(body.website).trim() !== "") {
    return new Response(JSON.stringify({ ok: true, bot: true }), {
      status: 200,
      headers: corsHeaders(allowOrigin, req)
    });
  }
  const {
    meaning = "",
    vision = "",
    // REQUIRED, 4k max
    fullName = "",
    email = "",
    phone = "",
    placement = "",
    scale = "",
    hear = "",
    consent = false,
    artist = "",
    source_link = ""
  } = body || {};
  const missing = [];
  if (!meaning.trim()) missing.push("Meaning");
  if (!vision.trim()) missing.push("Vision");
  if (!fullName.trim()) missing.push("Full name");
  if (!email.trim()) missing.push("Email");
  if (!phone.trim()) missing.push("Phone");
  if (!placement.trim()) missing.push("Placement");
  if (!scale.trim()) missing.push("Scale");
  if (!hear.trim()) missing.push("How did you hear about us");
  if (!consent) missing.push("Review consent");
  if (missing.length) {
    return new Response(
      JSON.stringify({ ok: false, error: "Missing: " + missing.join(", ") }),
      { status: 400, headers: corsHeaders(allowOrigin, req) }
    );
  }
  if (vision && vision.length > 4e3) {
    return new Response(
      JSON.stringify({
        ok: false,
        error: "Vision must be 4,000 characters or fewer."
      }),
      { status: 400, headers: corsHeaders(allowOrigin, req) }
    );
  }
  const submittedIso = (/* @__PURE__ */ new Date()).toISOString();
  const toEmail = "bookings@seventattoolv.com";
  const subject = `Booking Intake \u2014 ${fullName} (${scale}, ${placement})`;
  const text = [
    `Seven Tattoo \u2014 Booking Intake`,
    ``,
    `Submitted: ${submittedIso}`,
    `Meaning: ${meaning}`,
    `Vision: ${vision}`,
    `Full Name: ${fullName}`,
    `Email: ${email}`,
    `Phone: ${phone}`,
    `Placement: ${placement}`,
    `Scale: ${scale}`,
    `Heard About Us: ${hear}`,
    `Consent: ${consent ? "Yes" : "No"}`,
    `Artist (param): ${artist || "(not specified)"}`,
    `Source Link: ${source_link || "(none)"}`
  ].join("\n");
  const html = `
    <h2>Seven Tattoo \u2014 Booking Intake</h2>
    <p><strong>Submitted:</strong> ${submittedIso}</p>
    <p><strong>Meaning:</strong> ${escapeHtml(meaning)}</p>
    <p><strong>Vision:</strong> ${escapeHtml(vision)}</p>
    <p><strong>Full Name:</strong> ${escapeHtml(fullName)}</p>
    <p><strong>Email:</strong> ${escapeHtml(email)}</p>
    <p><strong>Phone:</strong> ${escapeHtml(phone)}</p>
    <p><strong>Placement:</strong> ${escapeHtml(placement)}</p>
    <p><strong>Scale:</strong> ${escapeHtml(scale)}</p>
    <p><strong>Heard About Us:</strong> ${escapeHtml(hear)}</p>
    <p><strong>Consent:</strong> ${consent ? "Yes" : "No"}</p>
    <p><strong>Artist (param):</strong> ${escapeHtml(
    artist || "(not specified)"
  )}</p>
    <p><strong>Source Link:</strong> <a href="${escapeAttr(
    source_link
  )}">${escapeHtml(source_link || "")}</a></p>
  `;
  try {
    await sgMail.send({
      to: toEmail,
      from: {
        email: "no-reply@seventattoolv.com",
        name: "Seven Tattoo Studio"
      },
      replyTo: { email, name: fullName },
      subject,
      text,
      html
    });
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: corsHeaders(allowOrigin, req)
    });
  } catch (err) {
    const msg = err?.response?.body?.errors?.[0]?.message || err?.message || "Email send failed";
    console.error(
      "SendGrid error:",
      err?.response?.body || err?.message || err
    );
    return new Response(JSON.stringify({ ok: false, error: msg }), {
      status: 500,
      headers: corsHeaders(allowOrigin, req)
    });
  }
};
function escapeHtml(str = "") {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
function escapeAttr(str = "") {
  return escapeHtml(str).replace(/"/g, "&quot;");
}
export {
  submit_booking_2_0_default as default
};
